import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt


class LogisticReg():                              # Logistic Regression class
    def __init__(self, learning_rate, iterations):
        self.learning_rate = learning_rate
        self.iterations = iterations


    def train(self, X, Y):
        self.m, self.n = X.shape
                                             # weight initialization
        self.W = np.ones(self.n).dot(2)      # W=2, b=0
        self.b = 0
        self.X = X
        self.Y = Y

        for i in range(self.iterations):
            self.update_weights()
        return self


    def update_weights(self):
        A = 1 / (1 + np.exp(- (self.X.dot(self.W) + self.b)))

        tmp = (A - self.Y.T)                     # gradients
        tmp = np.reshape(tmp, self.m)
        Wnew = np.dot(self.X.T, tmp) / self.m      # new weight, W'
        bnew = np.sum(tmp) / self.m                # new bias, b'

        # update weights
        self.W = self.W - self.learning_rate * Wnew    # modified weight, W = W - learning rate * W'
        self.b = self.b - self.learning_rate * bnew    # modified weight, b = W - learning rate * b'
        return self


    def predict(self, X):                                 # Sigmoid fn.
        Z = 1 / (1 + np.exp(- (X.dot(self.W) + self.b)))
        Y = np.where(Z > 0.5, 1, 0)
        return Y


def main():
    df = pd.read_csv("venv//diabetes.csv")   # Dataset
    data1 = df[df["Outcome"] == 0]
    data2 = df[df["Outcome"] == 1]
    x = data1.iloc[:, :-1].values
    y = data2.iloc[:, :-1].values          # Plotting relationship between variables
    plt.scatter(x[:, 0], x[:, 1], color='blue', marker='o', label='0')
    plt.scatter(y[:, 0], y[:, 1], color='red', marker='o', label='1')
    plt.xlabel('Pregnancies')
    plt.ylabel('Glucose')
    plt.legend(loc='upper left')
    plt.show()

    X = df.iloc[:, :-1].values
    Y = df.iloc[:, -1:].values

                                                              # Splitting datset for training & testing
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.5)

    model = LogisticReg(learning_rate=0.0001, iterations=3600)    # training the model for 3600 iterations
    model.train(X_train, Y_train)                                   # learning rate = 0.0001


    Y_pred = model.predict(X_test)         # Prediction
    print("Y predicted ",Y_pred)

    correct = 0                             # Calculating Accuracy
    count = 0
    for count in range(np.size(Y_pred)):
        if Y_test[count] == Y_pred[count]:
            correct = correct + 1
        count = count + 1

    print("Accuracy = ", (correct / count) * 100)


if __name__ == "__main__":
    main()

