import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
import matplotlib.pyplot as plt


class LogisticReg():                      # Logistic Regression class
    def __init__(self, lr, iterations):
        self.learning_rate = lr
        self.iterations = iterations

    def train(self, X, Y):
        self.m, self.n = X.shape                            # weight initialization
        self.W = np.ones(self.n).dot(2)                     # W=2, b=0
        self.b = 0
        self.X = X
        self.Y = Y

        for i in range(self.iterations):
            self.update_weights()
        return self


    def update_weights(self):
        A = 1 / (1 + np.exp(- (self.X.dot(self.W) + self.b)))

        tmp = (A - self.Y.T)                         # gradients
        tmp = np.reshape(tmp, self.m)
        Wnew = np.dot(self.X.T, tmp) / self.m         # new weight, W'
        bnew = np.sum(tmp) / self.m                   # new bias, b'

        self.W = self.W - self.learning_rate * Wnew    # modified weight, W = W - learning rate * W'
        self.b = self.b - self.learning_rate * bnew    # modified bias, b = b - learning rate * b'
        return self


    def predict(self, X, modelno):
        Z = 1 / (1 + np.exp(- (X.dot(self.W) + self.b)))        # Sigmoid fn.
        if modelno == 1:
            Y = np.where(Z > 0.5, 1, 0)
        else:
            Y = np.where(Z > 0.5, 2, 1)
        return Y


def main():
                                                        # Dataset
    df = pd.read_csv("venv//iris.csv")
    df1 = pd.read_csv('venv//iris.csv', skiprows=[i for i in range(51,101)])
    label = preprocessing.LabelEncoder()
    df.species = label.fit_transform(df.species)
    df1.species = label.fit_transform(df1.species)

    X = df.iloc[:, :-1].values                  # Plotting relationship between variables
    plt.scatter(X[:50, 0], X[:50, 1],color='blue', marker='o', label='vetosa')
    plt.scatter(X[50:100, 0], X[50:100, 1],color='green', marker='o', label='versicolor')
    plt.scatter(X[100:150, 0], X[100:150, 1],color='red', marker='o', label='virginica')
    plt.xlabel('Sepal length')
    plt.ylabel('Petal length')
    plt.legend(loc='upper left')
    plt.show()

    X1 = df.iloc[:100, :-1].values
    Y1 = df.iloc[:100, -1:].values
    X2 = df.iloc[50:, :-1].values
    Y2 = df.iloc[50:, -1:].values
    X3 = df1.iloc[:, :-1].values
    Y3 = df1.iloc[:, -1:].values

                                                                     # Splitting datset for training & testing
    X_train1, X_test1, Y_train1, Y_test1 = train_test_split(X1, Y1, test_size=0.5)
    X_train2, X_test2, Y_train2, Y_test2 = train_test_split(X2, Y2, test_size=0.5)
    X_train3, X_test3, Y_train3, Y_test3 = train_test_split(X3, Y3, test_size=0.5)


    model1 = LogisticReg(0.0003, iterations=3600)  # training the model for 3600 iterations
    model2 = LogisticReg(0.0003, iterations=3600)   # learning rate = 0.0003
    model3 = LogisticReg(0.0003, iterations=3600)
    model1.train(X_train1, Y_train1)
    model2.train(X_train2, Y_train2)
    model3.train(X_train3, Y_train3)

    Y_pred1 = model1.predict(X_test1,1)     # Prediction
    Y_pred2 = model2.predict(X_test2,2)
    Y_pred3 = model3.predict(X_test3,1)
    print(" Model 1 Prediction - ",Y_pred1)
    print("Model 2 Prediction - ",Y_pred2)

    correct1= 0
    count1 = 0
    correct2 = 0
    count2 = 0
    correct3 = 0
    count3 = 0
    for count1 in range(np.size(Y_pred1)):           # Calculating Accuracy
        if Y_test1[count1] == Y_pred1[count1]:
            correct1 = correct1 + 1
        count1 = count1 + 1

    for count2 in range(np.size(Y_pred2)):
        if Y_test2[count2] == Y_pred2[count2]:
            correct2 = correct2 + 1
        count2 = count2 + 1

    for count3 in range(np.size(Y_pred3)):
        if Y_test3[count3] == Y_pred3[count3]:
            correct3 = correct3 + 1
        count3 = count3 + 1

    for i in range(np.size(Y_pred3)):
        if Y_pred3[i] == 1:
            Y_pred3[i] = 2
    print("Model 3 Prediction - ",Y_pred3)

    print("Accuracy of Prediction for setosa & veriscolor = ", (correct1 / count1) * 100)
    print("Accuracy of Prediction for veriscolor & virginica = ", (correct2 / count2) * 100)
    print("Accuracy of Prediction for setosa & virginica = ", (correct3 / count3) * 100)
    print("Avg. Accuracy of the model = ", ((correct1+correct2+correct3) / (count1+count2+count3)) * 100)



if __name__ == "__main__":
    main()




