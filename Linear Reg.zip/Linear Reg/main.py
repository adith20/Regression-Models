import numpy                            # necessary libraries
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from scipy.stats import spearmanr
from sklearn.metrics import mean_squared_error

data = np.loadtxt("venv\crash.txt",dtype=float)  # dataset

x = data[:,1].reshape(-1,1)
y = data[:,0].reshape(-1,1)           # obtaining values of x & y variables from txt file
x.round(2)
y.round(2)

plt.scatter(x,y)
plt.xlabel('X (Independent)')
plt.ylabel('Original y (Dependent)')
plt.show()                               # plot between x and y



def UpdateWeight(x,y,lr):

    ypred = predict(x)
    global W,b,m
    Wnew = - (2 * (x.T).dot(y - ypred)) / m          # new weight, W' = -2X(Y - Ypred)/(no. of entries)
    bnew = - 2 * np.sum(y - ypred) / m               # new bias, b' = -2(Y - Ypred)/(no. of entries)

    W = W - lr * Wnew                         # modified weight, W = W - learning rate * W'
    b = b - lr * bnew                         # modified bias, b = b - learning rate * b'


def predict(x):
    return x.dot(W) + b      # matrix multiplication for y = wx + b


X_train, X_test, Y_train, Y_test = train_test_split(x, y, test_size=0.5)   # Splitting dataset for training & testing
m,n = X_train.shape
W = np.zeros(n)      # Weight matrix
b = 0                # bias

for i in range(1000):                        # training the model for 1000 iterations
    UpdateWeight(X_train, Y_train,0.0002)   # learning rate = 0.0002


Y_pred = predict(X_test)
shape = Y_pred.shape
Ymean = np.full(shape,np.mean(y))
MSE = mean_squared_error(Ymean,Y_pred)    # Calculating MSE =  Σ(yi - ŷi )^2/N
print("Mean squared error = ",MSE)

plt.scatter(X_test, Y_test, color='blue')   # Plot for X_test & Y predicted
plt.plot(X_test, Y_pred, color='red')
plt.xlabel('X Test(Independent)')
plt.ylabel('Y Predicted (Dependent)')
plt.ylim([0,60])
plt.show()

corr,p = spearmanr(X_test,Y_pred)           # correlation coeff r
corr = numpy.mean(corr)
p = numpy.mean(p)
print("SpearmanrResult(correlation=",corr," ,pvalue=",p,")")


N,ran = X_test.shape                                   # Least Square Regression
NΣxy = N*(np.sum(np.multiply(X_test,Y_test)))
ΣxΣy = np.multiply(np.sum(X_test),np.sum(Y_test))
NΣx2 = N*(np.sum(np.square(X_test)))
Σx2 = np.square(np.sum(X_test))

slope = (NΣxy - ΣxΣy)/(NΣx2 - Σx2 )                      # Calculation for slope
intercept = (np.sum(Y_test) - slope*np.sum(X_test))/N    # Calculation for intercept

print("Least sqr reg - Slope = ",slope,",Intercept = ",intercept)
ynew = numpy.multiply(X_test,slope) + intercept


plt.plot(X_test,ynew,color='blue')     # Plot for Least sqr reg - Best Fit line
plt.xlabel('X_test (Independent)')
plt.ylabel('Least sqr reg Y (Dependent)')
plt.show()



if __name__ == '__main__':
    print()


